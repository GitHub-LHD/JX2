/**
 * IPC cdev for JX2
 */

#ifndef MY_HWSERIAL_IPC
#define MY_HWSERIAL_IPC

#include "HardwareSerial.h"

/**
 * buffer datastructure and address
 */
struct rbuff {
  uint16_t rd;
  uint16_t wr;
  uint32_t size;
  uint8_t buff[0];
};
#define H2S_ADDR 0x03000000
#define S2H_ADDR 0x03010000

// this is the slave
class HardwareSerialIPC : public HardwareSerial
{
private:
  struct rbuff *h2s_buff;
  struct rbuff *s2h_buff;

  // the remaining write size in buffer
  int remain_size(struct rbuff *rbuf);
public:
  HardwareSerialIPC(int addr1, int addr2) : 
    h2s_buff((struct rbuff*)H2S_ADDR), s2h_buff((struct rbuff*)S2H_ADDR)
  {}
  HardwareSerialIPC() = default;
  void begin(unsigned int, uint8_t) override;
  void end() override;
  void flush(void) override;
  int available(void) override;
  int availableForWrite(void) override;
  int peek(void) override;
  int read(void) override;
  size_t write(uint8_t) override;
};

#endif