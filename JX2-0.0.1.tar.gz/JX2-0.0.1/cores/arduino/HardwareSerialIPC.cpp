/**
 * IPC cdev for JX2
 */

#include "HardwareSerialIPC.h"

void HardwareSerialIPC::begin(unsigned int baud, uint8_t config)
{
  // nothing to do
}

void HardwareSerialIPC::end()
{
  // nothing to do
}

void HardwareSerialIPC::flush()
{
  // nothing to do
}

int HardwareSerialIPC::available()
{
  return h2s_buff->rd == h2s_buff->wr ? 0 : 1;
}

int HardwareSerialIPC::remain_size(struct rbuff* rbuf)
{
  int used_size = rbuf->wr - rbuf->rd;
  if (used_size < 0) {
    used_size += rbuf->size;
  }
  return rbuf->size - used_size;
}

int HardwareSerialIPC::availableForWrite()
{
  return remain_size(s2h_buff) > 1 ? 1 : 0;
}

int HardwareSerialIPC::peek()
{
  return 0;
}

int HardwareSerialIPC::read()
{
  while (h2s_buff->rd == h2s_buff->wr) {
  }

  int retval = h2s_buff->buff[h2s_buff->rd];
  h2s_buff->rd++;
  if (h2s_buff->rd >= h2s_buff->size) {
    h2s_buff->rd = 0;
  }
  return retval;
}

size_t HardwareSerialIPC::write(uint8_t c)
{
  while (remain_size(s2h_buff) <= 1) {
  }

  s2h_buff->buff[s2h_buff->wr] = c;
  s2h_buff->wr++;
  if (s2h_buff->wr >= s2h_buff->size) {
    s2h_buff->wr = 0;
  }

  // trigger an interrupt
  reg32(CFG_TOP_BASE + CFG_SOC_CON5) = 0x00010001;

  return 1;
}
