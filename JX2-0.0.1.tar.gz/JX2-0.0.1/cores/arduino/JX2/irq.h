#ifndef __INTERRUPT_H__
#define __INTERRUPT_H__

#include "ppu.h"

#define IRQ                             0
#define FIQ                             1

#define  INT_ID_PP0           1
#define  INT_ID_PP1           2
#define  INT_ID_ROCKET        0x10
#define  INT_ID_CA7           0x20
//================define digital  Decimal ============================================== //
#define  INT_DMAC0_IRQ        (32+  0)
#define  INT_DMAC1_IRQ        (32+  1)
#define  INT_GMAC_IRQ         (32+  2)
#define  INT_OTG_IRQ          (32+  3)
#define  INT_EMMC0_IRQ        (32+  4)
#define  INT_EMMC1_IRQ        (32+  5)
#define  INT_EMMC2_IRQ        (32+  6)
#define  INT_SPI0_IRQ         (32+  7)
#define  INT_SPI1_IRQ         (32+  8)
#define  INT_I2C0_IRQ         (32+  9)
#define  INT_I2C1_IRQ         (32+ 10)
#define  INT_I2C2_IRQ         (32+ 11)
#define  INT_I2C3_IRQ         (32+ 12)
#define  INT_UART0_IRQ        (32+ 13)
#define  INT_UART1_IRQ        (32+ 14)
#define  INT_UART2_IRQ        (32+ 15)
#define  INT_UART3_IRQ        (32+ 16)
#define  INT_GPIO1_IRQ        (32+ 17)
#define  INT_GPIO2_IRQ        (32+ 18)
#define  INT_GPIO3_IRQ        (32+ 19)
#define  INT_GPIO4_IRQ        (32+ 20)
#define  INT_GPIO5_IRQ        (32+ 21)
#define  INT_GPIO6_IRQ        (32+ 22)
#define  INT_I2S0_IRQ         (32+ 23)
#define  INT_I2S1_IRQ         (32+ 24)
#define  INT_PWM0_IRQ         (32+ 25)
#define  INT_PWM1_IRQ         (32+ 26)
#define  INT_PWM2_IRQ         (32+ 27)
#define  INT_PWM3_IRQ         (32+ 28)
#define  INT_PWM4_IRQ         (32+ 29)
#define  INT_PWM5_IRQ         (32+ 30)
#define  INT_PWM6_IRQ         (32+ 31)
#define  INT_PWM7_IRQ         (32+ 32)
#define  INT_WDT_IRQ          (32+ 33)
#define  INT_CAN_IRQ          (32+ 34)
#define  INT_Timerx6_IRQ      (32+ 35)
#define  INT_GPIO0_IRQ        (32+ 36)
#define  INT_TIMERX2_IRQ      (32+ 37)
#define  INT_CAM_IRQ          (32+ 38)
#define  INT_LCDC_IRQ         (32+ 39)
#define  INT_DSIHOST_IRQ      (32+ 40)
#define  INT_CSIHOST_IRQ1     (32+ 41)
#define  INT_CSIHOST_IRQ2     (32+ 42)
#define  INT_PD_NPU_DMA_INTO  (32+ 43)

#define  INT_GLOBAL_INT_DISABLE       (32+ 44)       
#define  INT_GLOBAL_INT_DISABLE0      (32+ 45)       
#define  INT_GLOBAL_INT_DISABLE1      (32+ 46)       
#define  INT_GLOBAL_INT_DISABLE2      (32+ 47)       
#define  INT_GLOBAL_INT_DISABLE3      (32+ 48)       
#define  INT_GLOBAL_INT_DISABLE4      (32+ 49)       
#define  INT_GLOBAL_INT_DISABLE5      (32+ 50)       
#define  INT_SDMMC_DETN               (32+ 51)
#define  INT_SDMMC_DETN_IRQ           (32+ 52)
#define  INT_GMAC_PMT_IRQ             (32+ 53)
#define  INT_SARADC_INTO              (32+ 54)       
#define  INT_OTG_LINESTATE_IRQ        (32+ 55)       
#define  INT_OTG_BVALID_IRQ           (32+ 56)
#define  INT_OTG_DISCONNECT_IRQ       (32+ 57)
#define  INT_OTG_ID_IRQ               (32+ 58) 
#define  INT_CFG_SOC_CON5_3_0         (32+ 59)
#define  INT_CFG_SOC_CON5_7_4         (32+ 60)
#define  INT_CFG_SOC_CON5_11_8        (32+ 61)
#define  INT_CFG_SOC_CON5_15_12       (32+ 62)
#define  INT_TOPBM_AXI_DLOCK_IRQ      (32+ 63)
#define  INT_VBUS_DET_IRQ             (32+ 64)

///////////////////////////////////////////
//       GICD
///////////////////////////////////////////
#define      GICD_BASE                            0xFEDF1000
#define      GICD_CTLR                            0x0000
#define      GICD_TYPER                           0x0004
#define      GICD_IIDR                            0x0008
#define      GICD_SETSPI_SR                       0x0050 
#define      GICD_CLRSPI_SR                       0x0058
#define      GICD_ICDISR0                         0x0080
#define      GICD_ICDISR1                         0x0084
#define      GICD_ICDISR2                         0x0088
#define      GICD_ICDISR3                         0x008c
#define      GICD_ISENABLERn                      0x0100
#define      GICD_ICENABLERn                      0x0180
#define      GICD_ISPENDRn                        0x0200
#define      GICD_ICPENDRn                        0x0280
#define      GICD_ISACTIVERn                      0x0300
#define      GICD_IPRIORITYRn                     0x0400
#define      GICD_ITARGETSRn                      0x0800
#define      GICD_ICFGRn                          0x0c00
#define      GICD_PPISR                           0x0d00
#define      GICD_SPISRn                          0x0d04
#define      GICD_SGIR                            0x0f00
#define      GICD_CPENDSGIRn                      0x0f10
#define      GICD_SPENDSGIRn                      0x0f20


///////////////////////////////////////////
//       GICC
///////////////////////////////////////////
#define      GICC_BASE                            0xFEDF2000
#define      GICC_CTLR                            0x0000
#define      GICC_PMR                             0x0004
#define      GICC_BPR                             0x0008
#define      GICC_IAR                             0x000c
#define      GICC_EOIR                            0x0010
#define      GICC_RPR                             0x0014
#define      GICC_HPIR                            0x0018
#define      GICC_ABPR                            0x001c
#define      GICC_AIAR                            0x0020
#define      GICC_AEOIR                           0x0024
#define      GICC_AHPIR                           0x0028
#define      GICC_NSAPR0                          0x0030
#define      GICC_APR0                            0x00e0
#define      GICC_ICCIIDR                         0x00fc
#define      GICC_DIR                             0x0100

// cpu_num = 0,1,2,3 which core handle the interrupt
// mode = 0 irq, mode=1 fiq
void set_gic(int id_num, int priority, int cpu_num, int mode) 
{
  int reg_offset0,reg_offset1;
  int bit_offset0,bit_offset1;
  int temp;
  reg_offset0 = id_num / 32 ;
  reg_offset1 = id_num / 4  ;
  bit_offset0 = id_num - reg_offset0*32 ;
  bit_offset1 = id_num - reg_offset1*4  ;

  reg32(GICD_BASE + GICD_CTLR)=0x3;
  if (bit_offset0 == 64)
    reg32(GICD_BASE + GICD_ICENABLERn + reg_offset0 * 4) = 0x1 << bit_offset0;
  else
    reg32(GICD_BASE + GICD_ISENABLERn + reg_offset0 * 4) = 0x1 << bit_offset0;

  temp = reg32(GICD_BASE + GICD_IPRIORITYRn + reg_offset1*4);
  temp = temp & ~(0xFF << (bit_offset1 * 8) );
  reg32(GICD_BASE + GICD_IPRIORITYRn + reg_offset1*4) = priority << (bit_offset1 * 8) | temp;

  temp = reg32(GICD_BASE + GICD_ITARGETSRn + reg_offset1*4);
  temp = temp & ~(0xFF << (bit_offset1 * 8) );
  reg32(GICD_BASE + GICD_ITARGETSRn + reg_offset1*4)= cpu_num << (bit_offset1 * 8) | temp;
  // reg32(GICD_BASE + GICD_ITARGETSRn+reg_offset1*4)= 0x1 << (bit_offset1 * 8 + cpu_num );

  reg32(GICC_BASE + GICC_CTLR) = 0x7 | mode << 3;

  reg32(GICC_BASE + GICC_PMR) = 0xff;
}
#endif
