// Copyright 2016 ETH Zurich and University of Bologna.
// Copyright and related rights are licensed under the Solderpad Hardware
// License, Version 0.51 (the “License”); you may not use this file except in
// compliance with the License. You may obtain a copy of the License at
// http://solderpad.org/licenses/SHL-0.51. Unless required by applicable law
// or agreed to in writing, software, hardware and materials distributed under
// this License is distributed on an “AS IS” BASIS, WITHOUT WARRANTIES OR
// CONDITIONS OF ANY KIND, either express or implied. See the License for the
// specific language governing permissions and limitations under the License.

#include "uart.h"
#include "utils.h"
#include "ppu.h"
/**
 * Setup UART. The UART defaults to 8 bit character mode with 1 stop bit.
 *
 * parity       Enable/disable parity mode
 * clk_counter  Clock counter value that is used to derive the UART clock.
 *              It has to be in the range of 1..2^16.
 *              There is a prescaler in place that already divides the SoC
 *              clock by 16.  Since this is a counter, a value of 1 means that
 *              the SoC clock divided by 16*2 = 32 is used. A value of 31 would mean
 *              that we use the SoC clock divided by 16*32 = 512.
 */
//
//(1000000*F)/((clk_counter+1)*16) = baudrate ; F in MHz
//(1000000*25)/((49+1)*16) = 31250;  F=25MHz
//(1000000*50)/((49+1)*16) = 62500;  F=50MHz
//(1000000*62.5)/(49+1)*16)= 78125;  F=62.5MHz
//(1000000*80)/(49+1)*16)= 100000;  F=80MHz

writel(unsigned int val, unsigned addr){
    reg32(addr) = val;
};

void setup_gpio_sel(int offset, int portnum, int function){
    int val = function << (portnum << 1);
    int mask = (0x3 << (portnum << 1)) << 16;
    writel(val | mask, CFG_TOP_BASE + offset);
}

void uart_set_cfg(void)
{
  setup_gpio_sel(CFG_GPIO1C_IOMUX, PORTNUM7, UATR_FUNC); //uart1 rx
  setup_gpio_sel(CFG_GPIO1D_IOMUX, PORTNUM0, UATR_FUNC); //uart1 tx

  // 5:4 uart sorce selection : 3:480Mhz 0: fixed pll
  reg32( CRU_BASE + 0xc4 ) = 3 << (16+6)| 3 <<6;
  // set uart div to 480/20 = 24Mhz
  reg32( CRU_BASE + 0x1c0 ) = 0xff<<(16+8)|19 << 8;  //uart0 div[7:0]
  // fenzi/fenmu 11520000/480,000,000
  reg32( CRU_BASE + 0x1d4 ) = 192<<16|50000;
  // set uart clock div mode, 0:divfree,1:dec,2:np5
  reg32( CRU_BASE + 0x1b4) = 3 << (16) | 0;//set uart clock to divfree mode
  // reset uart srstn
  reg32( CRU_BASE + 0x54 ) = 0x20002000;  //uart 1
  reg32( CRU_BASE + 0x54 ) = 0x20000000;  //uart 1
  // reset uart presetn
  reg32( CRU_BASE + 0x44 ) = 0x40004000;   //uart 1 
  reg32( CRU_BASE + 0x44 ) = 0x40000000;  //uart 1
  // reg32( CRU_BASE + 0x84 ) = 0x0fff0000;  //apb bus clk config
  // reg32( CRU_BASE + 0x1c0 ) = 0x00ff0000;  //uart0 div[7:0]
  // reg32( CFG_TOP_BASE + 0x08 ) = 0xffff4140;  //S2 & .OEN ioconfig

  // uint16_t clk_counter = 13; //24M 115200 8
  uint32_t clk_counter = 13;
  //uint16_t clk_counter = ((24000000 / 115200) >> 4); //24M 115200 8
  /* uint16_t clk_counter = ((96000000 / 460800) >> 4); //24M 115200 8 */
  *(volatile int*)(UART_REG_LCR) = 0x83; //sets 8N1 and set DLAB to 1
  *(volatile int*)(UART_REG_DLM) = (clk_counter >> 8) & 0xFF;
  *(volatile int*)(UART_REG_DLL) =  clk_counter       & 0xFF;
  *(volatile int*)(UART_REG_FCR) = 0xA7; //enables 16byte FIFO and clear FIFOs
  *(volatile int*)(UART_REG_LCR) = 0x03; //sets 8N1 and set DLAB to 0

  // set IER (interrupt enable register) on UART
  // *(volatile unsigned int*)(UART_REG_IER) = ((*(volatile unsigned int*)(UART_REG_IER)) & 0xF0) | 0x02;
}

void uart_send(const char* str, unsigned int len) {
  unsigned int i;

  while(len > 0) {
    // process this in batches of 16 bytes to actually use the FIFO in the UART
    for(i = 0; (i < UART_FIFO_DEPTH) && (len > 0); i++) {
      // wait until there is space in the fifo
      while( (*(volatile unsigned int*)(UART_REG_LSR) & 0x20) == 0);
      // load FIFO
      *(volatile unsigned int*)(UART_REG_THR) = *str++;

      len--;
    }
  }
}

char uart_getchar() {
  while((*((volatile int*)UART_REG_LSR) & 0x1) != 0x1);

  return *(volatile int*)UART_REG_RBR;
}

void uart_sendchar(const char c) {
  // wait until there is space in the fifo
  while( (*(volatile unsigned int*)(UART_REG_LSR) & 0x20) == 0);

  // load FIFO
  *(volatile unsigned int*)(UART_REG_THR) = c;
}

void uart_wait_tx_done(void) {
  // wait until there is space in the fifo
  while( (*(volatile unsigned int*)(UART_REG_LSR) & 0x40) == 0);
}

