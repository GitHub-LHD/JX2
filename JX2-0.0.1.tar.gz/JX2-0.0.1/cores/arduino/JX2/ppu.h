#ifndef _PPU_CHIP_DEFINE_H_
#define _PPU_CHIP_DEFINE_H_

// #include "ld_addr.h"

#define CLINT 0x02000000
#define PLIC  0x0C000000
// extern int _dma_desc_start;
// extern int _sram_buffer_start;


#define BOOTCODE_JX2_DOWNLOAD_MODE        0xffff0180
#define BOOTCODE_JX2_EMMC_INIT            0xffff01a8
#define BOOTCODE_JX2_EMMC_LOAD            0xffff0fc8
#define BOOTCODE_JX2_EMMC_WRITE           0xffff1040
#define BOOTCODE_JX2_UART_LOAD            0xffff34b4
#define BOOTCODE_JX2_DFU_INIT             0xffff39ec
#define BOOTCODE_JX2_DFU_LOAD             0xffff3a80


#define DMA_DESC_BASE_ADDR        0xFED1A000//_dma_desc_start//0xFED18000
#define DMA_BUF_BASE_ADDR         0xFED1E000//0xFED1a800//_sram_buffer_start//0xFED1a800



#define reg32    *(unsigned int volatile *)

#define word64(x,y)    *(unsigned long volatile *)(x)=y
#define word32(x,y)    *(unsigned int  volatile *)(x)=y
#define short16(x,y)   *(unsigned short volatile *)(x)=y
#define char8(x,y)     *(unsigned char volatile  *)(x)=y

#define poll0(x,y)  while( reg32(x) & y ) ;
#define poll1(x,y)  while( (reg32(x) & y) == y );

#define DBG_CMD_BASE 0xFEC20000

// #define PASS *(unsigned int  volatile *)(DBG_CMD_BASE+0x0)=1
// #define FAIL *(unsigned int  volatile *)(DBG_CMD_BASE+0x4)=1
// #define STOP *(unsigned int  volatile *)(DBG_CMD_BASE+0x8)=1

#define PP0_PASS *(unsigned int  volatile *)(DBG_CMD_BASE+0x20)=1
#define PP0_FAIL *(unsigned int  volatile *)(DBG_CMD_BASE+0x24)=1
#define PP0_STOP *(unsigned int  volatile *)(DBG_CMD_BASE+0x28)=1

#define PP1_PASS *(unsigned int  volatile *)(DBG_CMD_BASE+0x40)=1
#define PP1_FAIL *(unsigned int  volatile *)(DBG_CMD_BASE+0x44)=1
#define PP1_STOP *(unsigned int  volatile *)(DBG_CMD_BASE+0x48)=1

#define CA7_PASS *(unsigned int  volatile *)(DBG_CMD_BASE+0x80)=1
#define CA7_FAIL *(unsigned int  volatile *)(DBG_CMD_BASE+0x84)=1
#define CA7_STOP *(unsigned int  volatile *)(DBG_CMD_BASE+0x88)=1

#define ROCKET_PASS *(unsigned int  volatile *)(DBG_CMD_BASE+0x60)=1
#define ROCKET_FAIL *(unsigned int  volatile *)(DBG_CMD_BASE+0x64)=1
#define ROCKET_STOP *(unsigned int  volatile *)(DBG_CMD_BASE+0x68)=1

// #define udelay(x)   { unsigned xx = x ; while( xx-- ) { asm("mov r0, r0"); } }
//#define udelay(x)   while( x = x-1 );

#define NPU_BASE             0xFF800000 // MAX: FFF
#define SRAM_BASE            0xFF700000

#define IOB0_BASE            0xFF700000 // MAX: 1FFFF
#define IOB1_BASE            0xFF720000 // MAX: 1FFFF
#define LSTM_BASE            0xFF740000 // MAX: FFF
#define WB_BASE              0xFF750000 // MAX: 7FFFF
#define WIB_BASE             0xFF7D0000 // MAX: FFF
#define BIAS_BASE            0xFF7E0000 // MAX: FFFF
#define INST_BASE            0xFF7F0000 // MAX: 1FFF

#define CAM_BASE             0xFEE00000
#define LCDC_BASE            0xFEE08000
#define MIPI_DSI_BASE        0xFEE10000
#define MIPI_CSI_BASE        0xFEE18000

#define DDRC_BASE            0xFEDC1000
#define DDRPHY_BASE          0xFEDC0000

#define CFGPHY_BASE          0xFED08000

/* CFGPHY_BASE + offset */
#define CFG_DSIPHY_RW_REG0       0x0000
#define CFG_DSIPHY_RW_REG1       0x0004
#define CFG_DSIPHY_RW_REG2       0x0008
#define CFG_DSIPHY_RW_REG3       0x000c
#define CFG_DSIPHY_RW_REG4       0x0010
#define CFG_DSIPHY_RW_REG5       0x0014
#define CFG_DSIPHY_RW_REG6       0x0018
#define CFG_DSIPHY_RW_REG7       0x001c
#define CFG_DSIPHY_RW_REG8       0x0020
#define CFG_DSIPHY_RW_REG9       0x0024
#define CFG_DSIPHY_RW_REG10      0x0028
#define CFG_DSIPHY_RW_REG11      0x002c
#define CFG_DSIPHY_RW_REG12      0x0030
#define CFG_DSIPHY_RW_REG13      0x0034
#define CFG_DSIPHY_RW_REG14      0x0038
#define CFG_DSIPHY_RW_REG15      0x003c

#define CFG_DSIPHY_RO_REG0       0x0100
#define CFG_DSIPHY_RO_REG1       0x0104
#define CFG_DSIPHY_RO_REG2       0x0108
#define CFG_DSIPHY_RO_REG3       0x010c
#define CFG_DSIPHY_RO_REG4       0x0110
#define CFG_DSIPHY_RO_REG5       0x0114
#define CFG_DSIPHY_RO_REG6       0x0118
#define CFG_DSIPHY_RO_REG7       0x011c
#define CFG_DSIPHY_RO_REG8       0x0120
#define CFG_DSIPHY_RO_REG9       0x0124
#define CFG_DSIPHY_RO_REG10      0x0128
#define CFG_DSIPHY_RO_REG11      0x0130
#define CFG_DSIPHY_RO_REG12      0x0134
#define CFG_DSIPHY_RO_REG13      0x0138
#define CFG_DSIPHY_RO_REG14      0x013c
#define CFG_DSIPHY_RO_REG15      0x0140
#define CFG_DSIPHY_RO_REG16      0x0144
#define CFG_DSIPHY_RO_REG17      0x0148
#define CFG_DSIPHY_RO_REG18      0x014c
#define CFG_DSIPHY_RO_REG19      0x0150
#define CFG_DSIPHY_RO_REG20      0x0154
#define CFG_DSIPHY_RO_REG21      0x0158
#define CFG_DSIPHY_RO_REG22      0x015c
#define CFG_DSIPHY_RO_REG23      0x0160
#define CFG_DSIPHY_RO_REG24      0x0164

#define CFG_CSIPHY_RW_REG0       0x0200
#define CFG_CSIPHY_RW_REG1       0x0204
#define CFG_CSIPHY_RW_REG2       0x0208
#define CFG_CSIPHY_RW_REG3       0x020c
#define CFG_CSIPHY_RW_REG4       0x0210
#define CFG_CSIPHY_RW_REG5       0x0214
#define CFG_CSIPHY_RW_REG6       0x0218
#define CFG_CSIPHY_RW_REG7       0x021c
#define CFG_CSIPHY_RW_REG8       0x0220
#define CFG_CSIPHY_RW_REG9       0x0224
#define CFG_CSIPHY_RW_REG10      0x0228
#define CFG_CSIPHY_RW_REG11      0x0230
#define CFG_CSIPHY_RW_REG12      0x0234
#define CFG_CSIPHY_RW_REG13      0x0238
#define CFG_CSIPHY_RW_REG14      0x023c
#define CFG_CSIPHY_RW_REG15      0x0240
#define CFG_CSIPHY_RW_REG16      0x0244
#define CFG_CSIPHY_RW_REG17      0x0248
#define CFG_CSIPHY_RW_REG18      0x024c
#define CFG_CSIPHY_RW_REG19      0x0250
#define CFG_CSIPHY_RW_REG20      0x0254
#define CFG_CSIPHY_RW_REG21      0x0258
#define CFG_CSIPHY_RW_REG22      0x025c
#define CFG_CSIPHY_RW_REG23      0x0260
#define CFG_CSIPHY_RW_REG24      0x0264
#define CFG_CSIPHY_RW_REG25      0x0268

#define CFG_CSIPHY_RO_REG0       0x0300
#define CFG_CSIPHY_RO_REG1       0x0304 
//-USB
#define CFG_USBPHY_RW_REG0       0x0400 
#define CFG_USBPHY_RW_REG1       0x0404 
#define CFG_USBPHY_RW_REG2       0x0408 
#define CFG_USBPHY_RW_REG3       0x040C 
#define CFG_USBPHY_RW_REG4       0x0410 
#define CFG_USBPHY_RW_REG5       0x0414 
#define CFG_USBPHY_RW_REG6       0x0418 
#define CFG_USBPHY_RO_REG0       0x0420 
#define CFG_USBPHY_RO_REG1       0x0424 


#define CFG_USBPHY_DETECT_CON     0x0430 
#define CFG_USBPHY_DETECT_ST      0x0434 
#define CFG_USBPHY_DETECT_CLR     0x0438 

#define CFG_USBPHY_ID_DETECT_CON             0x0440
#define CFG_USBPHY_LINESTATE_DETECT_CON      0x0444
#define CFG_USBPHY_BVALID_DETECT_CON         0x0448
#define CFG_USBPHY_DISCONNECT_DETECT_CON     0x044c


#define CRU_BASE             0xFED00000
#define CRU_AO_BASE          0xFED10000
#define CFG_AO_BASE          0xFED11000

//CRU_BASE + offset
#define PD_BM_CLKEN_IP_ADDR         0x0
#define PD_BM_RST_SRC_ADDR          0x4
#define PD_CPUB_CLKEN_IP_ADDR       0x8
#define PD_CPUB_RST_SRC0_ADDR       0xC
#define PD_CPUL_CLKEN_IP_ADDR       0x10
#define PD_CPUL_RST_SRC_ADDR        0x14
#define PD_NPU_CLKEN_IP_ADDR        0x18
#define PD_NPU_RST_SRC_ADDR         0x1C
#define PD_DDR_CLKEN_IP_ADDR        0x20
#define PD_DDR_RST_SRC_ADDR         0x24
#define PD_MM_CLKEN_IP_ADDR         0x28
#define PD_MM_RST_SRC_ADDR          0x2C
#define PD_PERI_CLKEN_IP0_ADDR      0x30
#define PD_PERI_CLKEN_IP1_ADDR      0x34
#define PD_PERI_CLKEN_IP2_ADDR      0x38
#define PD_PERI_CLKEN_IP3_ADDR      0x3C
#define PD_PERI_RST_SRC0_ADDR       0x40
#define PD_PERI_RST_SRC1_ADDR       0x44
#define CA7_CLK_SEL_DIV_CFG_ADDR    0x48
#define PD_PERI_RST_SRC2_ADDR       0x50
#define PD_PERI_RST_SRC3_ADDR       0x54
#define PD_PERI_RST_SRC4_ADDR       0x58
#define SYS_PLL_CFG_ADDR            0x5C
#define NPU_PLL_CFG_ADDR            0x60
#define DDR_PLL_CFG_ADDR            0x64
#define MM_PLL_CFG_ADDR             0x68
#define FIXED_PLL_CFG_ADDR          0x6C
#define SYSCLK_SEL_DIV_CFG_ADDR     0x70
#define BRV_CLK_SEL_DIV_CFG_ADDR    0x74
#define CPU_L_CLK_SEL_DIV_CFG_ADDR   0x78
#define NPUCLK_SEL_DIV_CFG_ADDR      0x7C
#define DDRCLK_SEL_DIV_CFG_ADDR      0x80
#define BMCLK_SEL_DIV_CFG0_ADDR      0x84
#define BMCLK_SEL_DIV_CFG1_ADDR      0x88
#define MMCLK_SEL_DIV_CFG_ADDR       0x8C
#define FIXEDCLK_SEL_DIV_CFG0_ADDR   0x90
#define FIXEDCLK_SEL_DIV_CFG1_ADDR   0x94
#define FIXEDCLK_SEL_DIV_CFG2_ADDR   0x98
#define FIXEDCLK_SEL_DIV_CFG3_ADDR   0x9C
#define FIXEDCLK_SEL_DIV_CFG4_ADDR   0xA0
#define FIXEDCLK_SEL_DIV_CFG5_ADDR   0xA4
#define FIXEDCLK_SEL_DIV_CFG6_ADDR   0xA8
#define FIXEDCLK_SEL_DIV_CFG7_ADDR   0xB0
#define FIXEDCLK_SEL_DIV_CFG8_ADDR   0xB4
#define FIXEDCLK_SEL_DIV_CFG9_ADDR   0xB8
#define FIXEDCLK_SEL_DIV_CFG10_ADDR  0xBC
#define FIXEDCLK_SEL_DIV_CFG11_ADDR  0xC0
#define FIXEDCLK_SEL_DIV_CFG12_ADDR  0xC4
#define FIXEDCLK_SEL_DIV_CFG13_ADDR  0xC8
#define PLL_BYPASS_CFG_ADDR          0xCC
#define PLL_LKDT_STATUS_ADDR         0xD0
#define MUXED_CLKOUT_VALID_ADDR      0xD4
#define DECIMAL_DIV_25M_ADDR         0xD8
#define DECIMAL_DIV_I2S0_ADDR        0xDC
#define DECIMAL_DIV_I2S1_ADDR        0xE0
#define PD_AO_RST_SRC_ADDR           0xE4
#define PD_CLKEN_CRU_ADDR            0xE8
#define GPIO_CLK_ENA_CFG_ADDR        0xEC
#define WDT_RST_EN_ADDR              0xF0
#define PHY_SOFT_RESET_ADDR          0xF4
#define SOFT_RSTN_PD_BM_TOP_ADDR     0xF8
#define SOFT_RSTN_PD_CPU_B_ADDR      0xFC
#define SOFT_RSTN_PD_CPU_L_ADDR      0x100
#define SOFT_RSTN_PD_NPU_ADDR        0x104
#define SOFT_RSTN_PD_MM_ADDR         0x108
#define SOFT_RSTN_PD_DDR_ADDR        0x10C
#define GPIO0_CLK_DIV_ADDR           0x110
#define GPIO1_CLK_DIV_ADDR           0x114
#define GPIO2_CLK_DIV_ADDR           0x118
#define GPIO3_CLK_DIV_ADDR           0x11C
#define GPIO4_CLK_DIV_ADDR           0x120
#define GPIO5_CLK_DIV_ADDR           0x124
#define GPIO6_CLK_DIV_ADDR           0x128
#define CLK_TIMERX6_DIV_ADDR         0x130
#define PCLK_DAP_DIV_ADDR            0x134
#define ACLK_CORE_DIV_ADDR           0x138
#define ACLK_MM2DDR_DIV_ADDR         0x13C
#define HCLK_MM_DIV_ADDR             0x140
#define PD_CPUB_RST_SRC1_ADDR        0x144
#define ACLK_NPU_CFG_ADDR            0x148
#define PD_PERI_PCLK_DIV_ADDR        0x14C
#define DPHYRX_REFCLK_DIV_ADDR       0x150
#define DPHYRX_CFGCLK_DIV_ADDR       0x154
#define DPHYRX_CLK_ENA_ADDR          0x158
#define SOFT_RSTN_GLOBAL_ADDR        0x160
#define I2S_CLK_SEL_ADDR             0x164
#define GMAC_CLK_CTRL0_ADDR          0x168
#define GMAC_CLK_CTRL1_ADDR          0x16C
#define I2S0_CLK_CTRL_ADDR           0x170
#define I2S1_CLK_CTRL_ADDR           0x174
#define MUXCLK_I2S0_DIV_ADDR         0x180
#define MUXCLK_I2S1_DIV_ADDR         0x184
#define SARADC_CLK_CTRL_ADDR         0x188
#define PMU_SOFT_RST_ADDR            0x190
#define FIXEDCLK_SEL_DIV_CFG14_ADDR  0x194
#define FIXEDCLK_SEL_DIV_CFG15_ADDR  0x198
#define FIXEDCLK_SEL_DIV_CFG16_ADDR  0x19C
#define TEST_CLK_SEL_ADDR            0x1A0
#define TEST_CLK_DIV_ADDR            0x1A4
#define BMCLK_SEL_DIV_CFG2_ADDR      0x1A8
#define SOFT_RSTN_PD_CA7_ADDR        0x1AC
#define SOFT_RSTN_PD_ROCKET_ADDR     0x1B0
#define FIXEDCLK_SEL_DIV_CFG17_ADDR  0x1B4
#define FIXEDCLK_SEL_DIV_CFG18_ADDR  0x1B8
#define FIXEDCLK_SEL_DIV_CFG19_ADDR  0x1BC
#define FIXEDCLK_SEL_DIV_CFG20_ADDR  0x1C0
#define PMU_CLK_DWNRST_SEL_ADDR      0x1C4
#define PMU_CLK_DWNCLK_SEL_ADDR      0x1C8
#define DECIMAL_DIV_UART0_ADDR       0x1D0
#define DECIMAL_DIV_UART1_ADDR       0x1D4
#define DECIMAL_DIV_UART2_ADDR       0x1D8
#define DECIMAL_DIV_UART3_ADDR       0x1DC

#define CFG_GPIO0A_IOMUX      0x000
#define CFG_GPIO0B_IOMUX      0x010
#define CFG_GPIO0C_IOMUX      0x020
#define CFG_GPIO0D_IOMUX      0x030

#define CFG_GPIO0A_SMT      0x050
#define CFG_GPIO0B_SMT      0x054
#define CFG_GPIO0C_SMT      0x058
#define CFG_GPIO0D_SMT      0x05c
#define CFG_GPIO0A_P      0x070
#define CFG_GPIO0B_P      0x074
#define CFG_GPIO0C_P      0x078
#define CFG_GPIO0D_P      0x07c

#define CFG_PVTM_CON0      0x080
#define CFG_PVTM_CON1      0x084

#define CFGAO_SOC_CON0      0x100
#define CFGAO_SOC_CON1      0x104
#define CFGAO_SOC_CON2      0x108
#define CFGAO_SOC_CON3      0x10c
#define CFGAO_SOC_STATUS0      0x120

#define CFG_RISCOS_REG0      0x180
#define CFG_RISCOS_REG1      0x184
#define CFG_RISCOS_REG2      0x188
#define CFG_RISCOS_REG3      0x18c
#define CFG_RISCOS_REG4      0x190
#define CFG_RISCOS_REG5      0x194
#define CFG_RISCOS_REG6      0x198
#define CFG_RISCOS_REG7      0x19c

#define CFG_OS_REG0      0x200
#define CFG_OS_REG1      0x204
#define CFG_OS_REG2      0x208
#define CFG_OS_REG3      0x20c
#define CFG_OS_REG4      0x210
#define CFG_OS_REG5      0x214
#define CFG_OS_REG6      0x218
#define CFG_OS_REG7      0x21c
#define CFG_OS_REG8      0x220
#define CFG_OS_REG9      0x224
#define CFG_OS_REG10      0x228
#define CFG_OS_REG11      0x22c

#define CFG_DLL_CON0      0x280
#define CFG_DLL_CON1      0x284
#define CFG_DLL_STATUS0      0x288
#define CFG_DLL_STATUS1      0x28c

#define CFG_SDMMC_DET      0x290
#define CFG_SDMMC_DET_CON      0x294
#define CFG_SDMMC_DET_ST      0x298
#define CFG_SDMMC_DET_CLR      0x29c


#define GPIO0_BASE           0xFED12000
#define TIMERX2_BASE         0xFED13000
#define APB_SRAM_BASE        0xFED14000
#define PMU_BASE             0xFED16000

#define DBG_A7_BASE          0xFEA00000
#define DBG_PP3_BASE         0xFEA08000
#define DBG_PP2_BASE         0xFEA10000
#define DBG_PP1_BASE         0xFEA18000
#define DBG_PP0_BASE         0xFEA20000

#define TCM_PP3_BASE         0xFEA30000
#define TCM_PP2_BASE         0xFEA40000
#define TCM_PP1_BASE         0xFEA50000
#define TCM_PP0_BASE         0xFEA60000

#define GIC_BASE	         	 0xFEDF0000

//#define SPI0_BASE            0xFFC00000

#define OTG_BASE             0xFEB00000
#define eMMC0_BASE           0xFEB40000
#define eMMC1_BASE           0xFEB50000
#define eMMC2_BASE           0xFEB60000

#define      SDMMC_CTRL                           0x0000
#define      SDMMC_PWREN                          0x0004
#define      SDMMC_CLKDIV                         0x0008
#define      SDMMC_CLKSRC                         0x000c
#define      SDMMC_CLKENA                         0x0010
#define      SDMMC_TMOUT                          0x0014
#define      SDMMC_CTYPE                          0x0018
#define      SDMMC_BLKSIZ                         0x001c
#define      SDMMC_BYTCNT                         0x0020
#define      SDMMC_INTMASK                        0x0024
#define      SDMMC_CMDARG                         0x0028
#define      SDMMC_CMD                            0x002c
#define      SDMMC_RESP0                          0x0030
#define      SDMMC_RESP1                          0x0034
#define      SDMMC_RESP2                          0x0038
#define      SDMMC_RESP3                          0x003c
#define      SDMMC_MINTSTS                        0x0040
#define      SDMMC_RINTSTS                        0x0044
#define      SDMMC_STATUS                         0x0048
#define      SDMMC_FIFOTH                         0x004c
#define      SDMMC_CDETECT                        0x0050
#define      SDMMC_WRTPRT                         0x0054
#define      SDMMC_TCBCNT                         0x005c
#define      SDMMC_TBBCNT                         0x0060
#define      SDMMC_DEBNCE                         0x0064
#define      SDMMC_USRID                          0x0068
#define      SDMMC_VERID                          0x006c
#define      SDMMC_HCON                           0x0070
#define      SDMMC_UHS_REG                        0x0074
#define      SDMMC_RST_N                          0x0078
#define      SDMMC_BMOD                           0x0080
#define      SDMMC_PLDMND                         0x0084
#define      SDMMC_DBADDR                         0x0088
#define      SDMMC_IDSTS                          0x008c
#define      SDMMC_IDINTEN                        0x0090
#define      SDMMC_DSCADDR                        0x0094
#define      SDMMC_BUFADDR                        0x0098
#define      SDMMC_CARDTHRCTL                     0x0100
#define      SDMMC_BACK_END_POWER                 0x0104
#define      SDMMC_UHS_REG_EXT                    0x0108
#define      SDMMC_EMMC_DDR_REG                   0x010c
#define      SDMMC_ENABLE_SHIFT                   0x0110
#define      SDMMC_FIFO_BASE                      0x0200


#define DMAC0_BASE           0xFEB70000
#define DMAC1_BASE           0xFEB80000
#define GMAC_BASE            0xFEB90000
#define CAN_BASE             0xFEC00000
#define PWM0_BASE            0xFEC01000
#define PWM1_BASE            0xFEC01200
#define PWM2_BASE            0xFEC01400
#define PWM3_BASE            0xFEC01600
#define PWM4_BASE            0xFEC01800
#define PWM5_BASE            0xFEC01a00
#define PWM6_BASE            0xFEC01c00
#define PWM7_BASE            0xFEC01e00
#define SPI0_BASE            0xFEC02000
#define SPI1_BASE            0xFEC02800
#define I2S0_BASE            0xFEC03000
#define I2S1_BASE            0xFEC04000
#define UART0_BASE           0xFEC05000
#define UART1_BASE           0xFEC06000
#define UART2_BASE           0xFEC07000
#define UART3_BASE           0xFEC08000
#define I2C0_BASE            0xFEC09000
#define I2C1_BASE            0xFEC0a000
#define I2C2_BASE            0xFEC0b000
#define I2C3_BASE            0xFEC0c000
#define Timerx6_BASE         0xFEC0d000
#define WDT_BASE             0xFEC0e000
#define GPIO1_BASE           0xFEC0f000
#define GPIO2_BASE           0xFEC10000
#define GPIO3_BASE           0xFEC11000
#define GPIO4_BASE           0xFEC12000
#define GPIO5_BASE           0xFEC13000
#define GPIO6_BASE           0xFEC14000
#define CFG_TOP_BASE         0xFEC15000

/* CFG_TOP_BASE + offset */
#define CFG_GPIO1A_IOMUX      0x000
#define CFG_GPIO1B_IOMUX      0x004
#define CFG_GPIO1C_IOMUX      0x008
#define CFG_GPIO1D_IOMUX      0x00c
#define CFG_GPIO2A_IOMUX      0x010
#define CFG_GPIO2B_IOMUX      0x014
#define CFG_GPIO2C_IOMUX      0x018
#define CFG_GPIO2D_IOMUX      0x01c
#define CFG_GPIO3A_IOMUX      0x020
#define CFG_GPIO3B_IOMUX      0x024
#define CFG_GPIO3C_IOMUX      0x028
#define CFG_GPIO3D_IOMUX      0x02c
#define CFG_GPIO4A_IOMUX      0x030
#define CFG_GPIO4B_IOMUX      0x034
#define CFG_GPIO4C_IOMUX      0x038
#define CFG_GPIO4D_IOMUX      0x03c
#define CFG_GPIO5A_IOMUX      0x040
#define CFG_GPIO5B_IOMUX      0x044
#define CFG_GPIO5C_IOMUX      0x048
#define CFG_GPIO5D_IOMUX      0x04c
#define CFG_GPIO6A_IOMUX      0x050
#define CFG_GPIO6B_IOMUX      0x054
#define CFG_GPIO6C_IOMUX      0x058
#define CFG_GPIO6D_IOMUX      0x05c

/*GPIO Function */
#define GPIO_FUNC 0
#define I2C_FUNC 1
#define SDIO_FUNC 1 
#define TESTCLK_FUNC 2
#define MIPI_TEST_FUNC 2

#define UATR_FUNC 1

#define PORTNUM0 0
#define PORTNUM1 1
#define PORTNUM2 2
#define PORTNUM3 3
#define PORTNUM4 4
#define PORTNUM5 5
#define PORTNUM6 6
#define PORTNUM7 7

#define CFG_GPIO1A_P      0x080
#define CFG_GPIO1B_P      0x084
#define CFG_GPIO1C_P      0x088
#define CFG_GPIO1D_P      0x08c
#define CFG_GPIO2A_P      0x090
#define CFG_GPIO2B_P      0x094
#define CFG_GPIO2C_P      0x098
#define CFG_GPIO2D_P      0x09c
#define CFG_GPIO3A_P      0x0a0
#define CFG_GPIO3B_P      0x0a4
#define CFG_GPIO3C_P      0x0a8
#define CFG_GPIO3D_P      0x0ac
#define CFG_GPIO4A_P      0x0b0
#define CFG_GPIO4B_P      0x0b4
#define CFG_GPIO4C_P      0x0b8
#define CFG_GPIO4D_P      0x0bc
#define CFG_GPIO5A_P      0x0c0
#define CFG_GPIO5B_P      0x0c4
#define CFG_GPIO5C_P      0x0c8
#define CFG_GPIO5D_P      0x0cc
#define CFG_GPIO6A_P      0x0d0
#define CFG_GPIO6B_P      0x0d4
#define CFG_GPIO6C_P      0x0d8
#define CFG_GPIO6D_P      0x0dc

#define CFG_SOC_CON0      0x100
#define CFG_SOC_CON1      0x104
#define CFG_SOC_CON2      0x108
#define CFG_SOC_CON3      0x10c
#define CFG_SOC_CON4      0x110
#define CFG_SOC_CON5      0x114
#define CFG_SOC_CON6      0x118
#define CFG_SOC_CON7      0x11c
#define CFG_SOC_CON8      0x120
#define CFG_SOC_CON9      0x124
#define CFG_SOC_CON10      0x128
#define CFG_SOC_CON11      0x12c
#define CFG_SOC_CON12      0x130
#define CFG_SOC_CON13      0x134
#define CFG_SOC_CON14      0x138
#define CFG_SOC_CON15      0x13c
#define CFG_SOC_CON16      0x140
#define CFG_SOC_CON17      0x144
#define CFG_SOC_CON18      0x148
#define CFG_SOC_CON19      0x14c
#define CFG_SOC_STATUS0      0x150
#define CFG_SOC_STATUS1      0x154
//- DW_ahb
#define CFG_AHB_RW_0      0x160
#define CFG_AHB_WTC_STATUS0      0x164
#define CFG_AHB_WTC_STATUS1      0x168
#define CFG_AHB_WTC_STATUS2      0x16c
#define CFG_AHB_WTC_STATUS3      0x170
#define CFG_AHB_WTC_STATUS4      0x174
#define CFG_AHB_WTC_STATUS5      0x178
#define CFG_AHB_WTC_STATUS6      0x17c
#define CFG_AHB_WTC_STATUS7      0x180
#define CFG_AHB_WTC_STATUS8      0x184
#define CFG_AHB_WTC_STATUS9      0x188
#define CFG_AHB_WTC_STATUS10      0x18c
#define CFG_AHB_WTC_STATUS11      0x190
//- PD CPUL
#define CFG_CPUL_RW_0      0x200
#define CFG_CPUL_RW_1      0x204
#define CFG_CPUL_RW_2      0x208
#define CFG_CPUL_RW_3      0x20c
#define CFG_CPUL_RW_4      0x210
#define CFG_CPUL_RW_5      0x214
#define CFG_CPUL_RW_6      0x218
#define CFG_CPUL_RW_7      0x21c
//- PD CPUB
#define CFG_CPUB_RW_0      0x220
#define CFG_CPUB_RW_1      0x224
#define CFG_CPUB_RW_2      0x228
                                           
//- SARADC
#define CFG_SARADC_RW_0      0x22c
#define CFG_SARADC_RW_1      0x230
#define CFG_SARADC_RO_2      0x234


#define ROM_BASE             0xFEC20000

/** Registers and pointers */
#define REGP(x) ((volatile unsigned int*)(x))
#define REG(x) (*((volatile unsigned int*)(x)))
#define REGP_8(x) (((volatile uint8_t*)(x)))

#endif
